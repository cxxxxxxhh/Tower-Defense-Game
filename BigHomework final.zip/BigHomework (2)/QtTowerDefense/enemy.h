﻿#ifndef ENEMY_H
#define ENEMY_H

#include <QVector>
#include <QString>
#include "globalstruct.h"   //坐标结构

//怪物类
class Enemy
{
private:
    QVector<CoorObject*> Waypoint;  //存储怪物路径点数组
    int _x, _y;
    int _width, _height;
    QString ImgPath;
    int id;
    int health;
    int _speed = 10;       //怪物移动速度

public:

    Enemy(CoorObject **pointarr, int arrlength, int x, int y, int fid);  //构造

    bool Move();

    int GetX() const;
    int GetY() const;
    int GetWidth() const;
    int GetHeight() const;
    QString GetImgPath() const; //获取图片路径
    int GetId() const;
    int GetHealth() const;
    void SetHealth(int);
};

#endif // ENEMY_H
