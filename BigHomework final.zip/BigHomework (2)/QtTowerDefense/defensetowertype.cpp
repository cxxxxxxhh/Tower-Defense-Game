﻿#pragma execution_character_set("utf-8")
#include "defensetowertype.h"

//构造
DefenseTowerType::DefenseTowerType(int x, int y, int width, int height)
    : _x(x), _y(y), _width(width), _height(height) {}

int DefenseTowerType::GetX() const
{
    return _x;
}

int DefenseTowerType::GetY() const
{
    return _y;
}

int DefenseTowerType::GetWidth() const
{
    return _width;
}

int DefenseTowerType::GetHeight() const
{
    return _height;
}

