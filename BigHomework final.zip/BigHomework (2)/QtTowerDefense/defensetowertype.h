﻿#ifndef DEFENSETOWERTYPE_H
#define DEFENSETOWERTYPE_H

#include <QVector>

//防御塔坑类
class DefenseTowerType
{
private:
    const int _x, _y;           //位置坐标
    const int _width, _height;  //宽高

public:
    //构造    参数：防御塔坑坐标、宽高
    DefenseTowerType(int x, int y, int width = 80, int height = 80);

    int GetX() const;
    int GetY() const;
    int GetWidth() const;
    int GetHeight() const;
    //bool Exist() const;
};

#endif // DEFENSETOWERTYPE_H
