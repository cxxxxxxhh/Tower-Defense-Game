﻿#pragma execution_character_set("utf-8")
#include "higheralgebra.h"
//高代
HigherAlgebra::HigherAlgebra(int x, int y, int FUpLeftX, int FUpLeftY, int Fwidth, int Fheight)
{
    _x = x, _y = y;
    DefImgPath = QString(":/image/buygreen.png");
    width = Fwidth, height = Fheight;
    UpLeftX = FUpLeftX, UpLeftY = FUpLeftY;

    Range = 200;//范围

    BullPath = QString(":/image/greenbullet.png");
    bullwidth = 30, bullheight = 30;

    attack = 40;

    ExplRangeWidth = 65;
    ExplRangeHeight = ExplRangeWidth;
}
