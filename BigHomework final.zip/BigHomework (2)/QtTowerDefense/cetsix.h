﻿#ifndef CETSIX_H
#define CETSIX_H

#include "defetowerparent.h"

//大炮防御塔类
class CetSix : public DefeTowerParent
{
protected:

public:
    CetSix(int x, int y, int FUpLeftX, int FUpLeftY, int Fwidth = 80, int Fheight = 80);
};

#endif // CETSIX_H
