﻿#pragma execution_character_set("utf-8")
#include "enemy.h"
#include <QDebug>

//enemy类函数实现
Enemy::Enemy(CoorObject **pointarr, int arrlength, int x, int y, int fid) :
    _x(x), _y(y), id(fid)
{
    for(int i = 0; i < arrlength; i++)      //将传进来的数组插入到Waypoint动态数组
        Waypoint.push_back(pointarr[i]);//存储怪物路径



    switch (id)
    {
    case 1:
        health = 100;
        _width = 64, _height = 64;
        ImgPath = ":/image/monster1.png";
        break;
    case 2:
        health = 120;
        _width = 86, _height = 64;
        ImgPath = ":/image/monster2.png";
        break;
    case 3:
        health = 650;
        _width = 160, _height = 120;
        ImgPath = ":/image/monster3.png";
        break;
    case 4:
        health = 310;
        _width = 98, _height = 70;
        ImgPath = ":/image/monster4.png";
        break;
    default:
        break;
    }
}
int Enemy::GetX() const
{
    return _x;
}

int Enemy::GetY() const
{
    return _y;
}

int Enemy::GetWidth() const
{
    return _width;
}

int Enemy::GetHeight() const
{
    return _height;
}

QString Enemy::GetImgPath() const
{
    return ImgPath;
}

int Enemy::GetId() const
{
    return id;
}

int Enemy::GetHealth() const
{
    return health;
}

void Enemy::SetHealth(int fhealth)
{
    health = fhealth;
}



//怪物移动
bool Enemy::Move()
{
    if(Waypoint.empty())
        return true;

    //如果第一个路径点的y小于怪物原本的路径点，则怪物向下走
    if (Waypoint.at(0)->y > _y) //下
    {
       _y += _speed;
        return false;
    }

    if (Waypoint.at(0)->x < _x) //左
    {
        _x -= _speed;
        return false;
    }

    if (Waypoint.at(0)->x > _x) //右
    {
        _x += _speed;
        return false;
    }

    if (Waypoint.at(0)->y < _y) //上
    {
        _y -= _speed;
        return false;
    }

    //删除这个路径点
//
    if (Waypoint.at(0)->y == _y && Waypoint.at(0)->x == _x)
    {
        delete Waypoint.begin();
        Waypoint.erase(Waypoint.begin());       //从数组中删除

//        return false;
    }

    return false;
}


