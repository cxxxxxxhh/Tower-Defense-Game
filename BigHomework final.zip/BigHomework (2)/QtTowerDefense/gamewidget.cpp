﻿
#include "gamewidget.h"
#include "ui_gamewidget.h"
#include <QDebug>
#include "globalstruct.h"
#include <math.h>
#include "higheralgebra.h"
#include "programming.h"
#include "mathanalysis.h"
#include "cetsix.h"
#include <QPushButton>
#include "gamehead.h"
//#include<qdebug.h>


GameWidget::GameWidget(QWidget *parent, int level) :
    QDialog(parent),
    LevelNumber(level),//参数parent指向父窗口，如果为0，就是一个顶级窗口
    ui(new Ui::GameWidget)
{
    ui->setupUi(this);

    setFixedSize(1040, 640);
    if(level == 0){
        setWindowTitle("easy");
    }else{
        setWindowTitle("difficult");
    };//设置开始的选择框

  DisplayAllRange = true;

  QLabel *victorylable = new QLabel(this);
    victorylable->move(176, 180);
    victorylable->setFont(QFont("Arial", 20));
    victorylable->setText(QString("Victory"));
    victorylable->hide();//设置胜利之后字体
    QLabel *defeatable = new QLabel(this);
      defeatable->move(176, 180);
      defeatable->setFont(QFont("Arial", 20));
      defeatable->setText(QString("Lose"));
      defeatable->hide();//设置胜利之后字体

    moneylable->move(20, 40);
    setStyleSheet("color:black");
    moneylable->setFont(QFont("Arial", 24));
    moneylable->setText(QString("money：%1").arg(money));
    QLabel *lifelable = new QLabel(this);
    lifelable->setGeometry(20, 100, 220, 40);
    lifelable->setFont(QFont("Arial", 24));
    lifelable->setText(QString("life：%1").arg(life));

    QTimer* timer = new QTimer(this);
    timer->start(120);//怪物随机事件

    QTimer* timer2 = new QTimer(this);
    timer2->start(2000);//敌人

    QMediaPlayer* player=new QMediaPlayer;
    player->setMedia(QUrl("qrc:/music/easy.mp3"));
    player->setVolume(30);
    player->play();
   // qDebug()<<"测试";

    //this->close();
//       music=new QMediaPlayer;
//       connect(music,SIGNAL(positionChanged(qint64)),this,SLOT(postitionChanged(qint64)));
//       music->setMedia(QUrl::fromLocalFile(":\music\music.mp3"));
//       music->setVolume(80);
//       music->play();

    connect(timer2,&QTimer::timeout,[=]()//敌人路径
    {
        switch (LevelNumber) {
        case 0:
        {
            CoorObject* Waypointarr1[] = {new CoorObject(X40(8), X40(6)), new CoorObject(X40(2), X40(6)), new CoorObject(X40(2), X40(13)), new CoorObject(X40(19), X40(13)), new CoorObject(X40(19), X40(9)), new CoorObject(homecoor->x, homecoor->y)};
            CoorObject* Waypointarr2[] = {new CoorObject(X40(20), X40(5)), new CoorObject(X40(14), X40(5)), new CoorObject(X40(14), X40(9)), new CoorObject(X40(8), X40(9)), new CoorObject(X40(8), X40(6)), new CoorObject(X40(2), X40(6)),
                                       new CoorObject(X40(2), X40(13)), new CoorObject(X40(19), X40(13)), new CoorObject(X40(19), X40(9)), new CoorObject(homecoor->x, homecoor->y)};
            //其中用了宏
            CoorObject staco[] = {CoorObject(8, 0), CoorObject(20, 0), CoorObject(8, -1), CoorObject(20, -1)};
            //坐标结构体，表示四个起始点
            int PathLength[] = {sizeof(Waypointarr1)/sizeof(CoorObject*), sizeof(Waypointarr1)/sizeof(CoorObject*)};

            IrodMonsProgDefa(Waypointarr1, Waypointarr2, staco, PathLength, victorylable);

            break;
        }
        case 1:
        {

            CoorObject* Waypointarr1[] = {new CoorObject(X40(4), X40(8)), new CoorObject(X40(20), X40(8)), new CoorObject(X40(20), X40(13)), new CoorObject(X40(6), X40(13)), new CoorObject(homecoor->x, homecoor->y)};
            CoorObject* Waypointarr2[] = {new CoorObject(X40(11), X40(8)), new CoorObject(X40(20), X40(8)), new CoorObject(X40(20), X40(13)), new CoorObject(X40(6), X40(13)), new CoorObject(homecoor->x, homecoor->y)};

            CoorObject staco[] = {CoorObject(4, 0), CoorObject(11, 0), CoorObject(4, -1), CoorObject(11, -1)};

            int PathLength[] = {sizeof(Waypointarr1)/sizeof(CoorObject*), sizeof(Waypointarr1)/sizeof(CoorObject*)};

            IrodMonsProgDefa(Waypointarr1, Waypointarr2, staco, PathLength, victorylable);
            break;
        }

        case 2:
        {
            CoorObject* Waypointarr1[] = {new CoorObject(X40(12), X40(9)), new CoorObject(X40(8), X40(9)), new CoorObject(X40(8), X40(0)), new CoorObject(homecoor->x, homecoor->y)};
            CoorObject* Waypointarr2[] = {new CoorObject(X40(12), X40(9)), new CoorObject(X40(16), X40(9)), new CoorObject(X40(16), X40(0)), new CoorObject(homecoor->x, homecoor->y)};

            CoorObject staco[] = {CoorObject(12, 16), CoorObject(12, 16), CoorObject(12, 17), CoorObject(12, 18)};
            int PathLength[] = {sizeof(Waypointarr1)/sizeof(CoorObject*), sizeof(Waypointarr1)/sizeof(CoorObject*)};

            IrodMonsProgDefa(Waypointarr1, Waypointarr2, staco, PathLength, victorylable);
            break;//两条路产生敌人
        }
        default:
            break;
        }
    });





    connect(timer,&QTimer::timeout,[=]()//信号发送者，信号，lambda表达式  重载版本，让timeout和槽函数联系起来
    {
        for (auto defei : DefeTowerVec)//自动推导
        {
            if (!defei->GetAimsMonster())//不是目标怪物
            {
                for(int i = MonsterVec.size() - 1; i >= 0; i--)//改了很久发现必须使用宏
                    if (DistBetPoints(defei->GetUpLeftX() + 40, defei->GetUpLeftY() + 40,//两点之间距离
                                      MonsterVec.at(i)->GetX() + (MonsterVec.at(i)->GetWidth() >> 1),
                                      MonsterVec.at(i)->GetY() + (MonsterVec.at(i)->GetHeight() >> 1)) <= defei->GetRange())
                    {
                        defei->SetAimsMonster(MonsterVec.at(i));
                        break;
                    }
            }
            else
                if (DistBetPoints(defei->GetUpLeftX() + 40, defei->GetUpLeftY() + 40,
                                  defei->GetAimsMonster()->GetX() + (defei->GetAimsMonster()->GetWidth() >> 1),
                                  defei->GetAimsMonster()->GetY() + (defei->GetAimsMonster()->GetHeight() >> 1)) <= defei->GetRange())
                {

                    defei->SetRotatAngle(//旋转角度
                                atan2
                                (
                                    defei->GetAimsMonster()->GetY()/* + (defei->GetAimsMonster()->GetHeight() >> 1)*/ - defei->GetUpLeftY() + 40,
                                    defei->GetAimsMonster()->GetX()/* + (defei->GetAimsMonster()->GetWidth() >> 1)*/ - defei->GetUpLeftX()
                                    ) * 180 / 3.1415 );

                    defei->InterBullet();//发射子弹
                }


            if (defei->GetAimsMonster())
                if (DistBetPoints(defei->GetUpLeftX() + 40, defei->GetUpLeftY() + 40,
                                  defei->GetAimsMonster()->GetX() + (defei->GetAimsMonster()->GetWidth() >> 1),
                                  defei->GetAimsMonster()->GetY() + (defei->GetAimsMonster()->GetHeight() >> 1)) > defei->GetRange())
                    defei->SetAimsMonster(NULL);//离开了之后，删除敌人在数组中的位置
        }


        for (auto defei : DefeTowerVec)
            defei->BulletMove();


        for (auto Moni = MonsterVec.begin(); Moni != MonsterVec.end(); Moni++)//遍历敌人
            if((*Moni)->Move())
            {
                delete *Moni;
                MonsterVec.erase(Moni);//删掉敌人

                life--;//丢一条命
                lifelable->setText(QString("life：%1").arg(life));

                if (life <= 0) this->close();//没命了

                break;
            }


        for (auto defei : DefeTowerVec)
        {
            auto &tbullvec = defei->GetBulletVec();
            for (auto bullit = tbullvec.begin(); bullit != tbullvec.end(); bullit++)
                for (auto monit = MonsterVec.begin(); monit != MonsterVec.end(); monit++)
                    if ((*bullit)->GetX() + (defei->GetBulletWidth() >> 1) >= (*monit)->GetX() && (*bullit)->GetX() <= (*monit)->GetX() + (*monit)->GetWidth() &&
                            (*bullit)->GetY() + (defei->GetBulletHeight() >> 1) >= (*monit)->GetY() && (*bullit)->GetY() <= (*monit)->GetY() + (*monit)->GetHeight())
                    {
                        tbullvec.erase(bullit);     //删除子弹

                        (*monit)->SetHealth((*monit)->GetHealth() - defei->GetAttack());
                        ExploEffectCoor.push_back(new ExploObject(CoorObject((*monit)->GetX() + ((*monit)->GetWidth() >> 1), (*monit)->GetY() + ((*monit)->GetHeight() >> 1)),
                                                               defei->GetExplRangeWidth(), defei->GetExplRangeHeight()));//插入爆炸数组

                        if ((*monit)->GetHealth() <= 0)
                        {

                            for (auto defei2 : DefeTowerVec)
                                if (defei2->GetAimsMonster() == *monit)
                                    defei2->SetAimsMonster(NULL);//判断目标怪物是否已经存在

                            MonsterVec.erase(monit);
                            money += RewardMoney;
                            moneylable->setText(QString("money：%1").arg(money));
                        }

                        goto L1;
                    }
L1:;
        }

        for (auto expli = ExploEffectCoor.begin(); expli != ExploEffectCoor.end(); expli++)
        {
            if((*expli)->index >= 8)
            {
                ExploEffectCoor.erase(expli);
                break;
            }

            (*expli)->index++;
        }

        update();
    });
}
//下面开始实现函数
GameWidget::~GameWidget()
{
    for (auto it = TowerPitVec.begin(); it != TowerPitVec.end(); it++)
    {
        delete *it;
        *it = NULL;
    }

    delete SelBox;
    SelBox = NULL;

    for (auto it = DefeTowerVec.begin(); it != DefeTowerVec.end(); it++)
    {
        delete *it;
        *it = NULL;
    }

    for (auto it = MonsterVec.begin(); it != MonsterVec.end(); it++)
    {
        delete *it;
        *it = NULL;
    }


    for (auto it = ExploEffectCoor.begin(); it != ExploEffectCoor.end(); it++)
    {
        delete *it;
        *it = NULL;
    }//这么多数组，释放内存

    delete homecoor;
    delete ui;
};//析构函数

void GameWidget::IrodMonsProgDefa(CoorObject** Waypointarr1, CoorObject** Waypointarr2, CoorObject* staco, int* PathLength, QLabel* victorylable)
{
    CoorObject** pointarr[] = {Waypointarr1, Waypointarr2};

    if(counter >= 1 && counter <= 14)
    {
        InsterMonster(0, 0, 1); //001表示第几条路径、第几个起始点、怪物编号
    }
    else if(counter > 14 && counter <= 34)
    {
        InsterMonster(0, 0, 1);
        InsterMonster(1, 1, 2);
    }
    else if (counter > 34 && counter <= 35)
    {
        InsterMonster(0, 0, 3);
        InsterMonster(1, 1, 3);
    }
    else if (counter > 35 && counter <= 52)
    {
        InsterMonster(0, 2, 4);
        InsterMonster(0, 0, 4);
        InsterMonster(1, 1, 1);
    }
    if(counter > 52 && counter <= 56)
    {
        InsterMonster(0, 0, 3);
        InsterMonster(1, 1, 3);
    }
    if (counter > 52 && counter <= 71)
    {
        InsterMonster(0, 2, 2);
        InsterMonster(1, 3, 1);
        InsterMonster(1, 1, 4);
    }//在count到达什么数时插入什么敌人

    if (counter > 100 && MonsterVec.empty())//敌人走完，胜利
        victorylable->show();

    counter++;
    update();
}

//void GameWidget::drawMusic(QPainter &painter)
//{
//     painter.drawPixmap(60,60,60,60,QPixmap(":/image/music.png"));//拆塔按钮
//}
void GameWidget::drawMapArr(QPainter& painter)//画地图
{
    //1
    int Map_1[16][26] =
    {
        0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 3, 6, 1, 1, 3, 6, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 6, 6, 1, 1, 6, 6, 0, 0, 0, 0, 0, 0, 3, 6, 1, 1, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 3, 6, 1, 1, 3, 6, 0, 0, 0, 0, 0, 0, 6, 6, 1, 1, 3, 6, 0, 0, 0,
        0, 0, 0, 0, 0, 6, 6, 1, 1, 6, 6, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 6, 6, 0, 0, 0,
        0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0,
        0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 3, 6, 0, 1, 1, 0, 0, 0, 0, 3, 6, 0, 0, 0, 0, 0,
        0, 1, 1, 0, 3, 6, 0, 1, 1, 0, 6, 6, 0, 1, 1, 0, 3, 6, 0, 6, 6, 0, 0, 0, 0, 0,
        0, 1, 1, 0, 6, 6, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 6, 6, 1, 1, 1, 1, 1, 1, 5, 1,
        0, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1,
        0, 1, 1, 0, 3, 6, 0, 0, 3, 6, 1, 1, 3, 6, 0, 0, 3, 6, 1, 1, 3, 6, 3, 6, 1, 1,
        0, 1, 1, 0, 6, 6, 0, 0, 6, 6, 1, 1, 6, 6, 0, 0, 6, 6, 1, 1, 6, 6, 3, 6, 1, 1,
        0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 6, 3, 6, 1, 1,
        0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 6, 6, 6, 6, 1, 1,
        0, 0, 0, 0, 3, 6, 3, 6, 3, 6, 3, 6, 3, 6, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1,
        0, 0, 0, 0, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1,
    };
    //2
    int Map_2[16][26] =
    {
        0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 1, 1, 3, 6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 1, 1, 6, 6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 3, 6, 1, 1, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 6, 6, 1, 1, 3, 6, 3, 6, 0, 1, 1, 0, 0, 3, 6, 0, 0, 3, 6, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 1, 1, 3, 6, 6, 6, 0, 1, 1, 0, 0, 6, 6, 0, 0, 6, 6, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0,
        0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 3, 6, 0, 0, 0, 0, 3, 6, 0, 0, 0, 0, 3, 6, 1, 1, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 6, 6, 0, 0, 0, 0, 6, 6, 0, 0, 0, 0, 6, 6, 1, 1, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 5, 1, 3, 6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 1, 1, 6, 6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    };
    //3
    int Map_3[16][26] =
    {
        1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 5, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        1, 1, 0, 0, 0, 0, 0, 1, 1, 3, 6, 3, 6, 3, 6, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        1, 1, 0, 0, 0, 0, 0, 1, 1, 6, 6, 6, 6, 6, 6, 1, 1, 3, 6, 0, 0, 0, 0, 0, 0, 0,
        1, 1, 0, 0, 0, 3, 6, 1, 1, 0, 0, 3, 6, 0, 0, 1, 1, 6, 6, 0, 0, 0, 0, 0, 0, 0,
        1, 1, 0, 0, 0, 6, 6, 1, 1, 0, 0, 6, 6, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        1, 1, 0, 0, 0, 0, 0, 1, 1, 3, 6, 0, 0, 3, 6, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        1, 1, 0, 0, 0, 0, 0, 1, 1, 6, 6, 0, 0, 6, 6, 1, 1, 1, 1, 1, 1 ,1, 1, 1, 1, 1,
        1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
        1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1, 3, 6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1, 6, 6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    };
//最后决定只做简单和困难模式，选择1和3两个地图，但是留着第二个地图无所谓
    int Map[16][26];    //拷贝关卡数组

    switch (LevelNumber)
    {
    case 0:
        memcpy(Map, Map_1, sizeof(Map));
        break;
    case 1:
        memcpy(Map, Map_2, sizeof(Map));
        break;
    case 2:
        memcpy(Map, Map_3, sizeof(Map));
        break;
    default:
        break;
    }//选择第几关

    for (int j = 0; j < 16; j++)
           for (int i = 0; i < 26; i++)
           {
               switch (Map[j][i])
               {
               case 0:     //院徽
                   painter.drawPixmap(i * 40, j * 40, 40, 40,
                                      QPixmap(":/image/grass.png"));
                   break;
               case 1:     //校徽
                   painter.drawPixmap(i * 40, j * 40, 40, 40,
                                      QPixmap(":/image/ground.png"));
                   break;
               case 3:     //塔坑
                   painter.drawPixmap(i * 40, j * 40, 80, 80,
                                      QPixmap(":/image/brick.png"));
                   TowerPitVec.push_back(new DefenseTowerType(i * 40, j * 40));
                   break;
               case 5:
                   painter.drawPixmap(i * 40, j * 40, 40, 40,
                                      QPixmap(":/image/ground.png"));
                   homecoor->x = i * 40, homecoor->y = j * 40;
                   break;
                              }
                          }

                      painter.drawPixmap(homecoor->x, homecoor->y, 80, 80,
                                         QPixmap(":/image/house.png")); //画出博士帽
                  }

void GameWidget::drawMonster(QPainter& painter)
{
    for (auto moni : MonsterVec)//画出怪物
        painter.drawPixmap(moni->GetX(), moni->GetY(), moni->GetWidth(), moni->GetHeight(), QPixmap(moni->GetImgPath()));
}

void GameWidget::drawSelectionBox(QPainter& painter)//选择框，4个
{

    if (!SelBox->GetDisplay())//光标放在塔坑
        return;


    painter.drawPixmap(SelBox->GetX(), SelBox->GetY(), SelBox->GetWidth(), SelBox->GetHeight(),
                       QPixmap(SelBox->GetImgPath()));


    SubbutObject *ASubBut = SelBox->GetSelSubBut();    //子按钮
    for (int i = 0; i < 4; i++)
        painter.drawPixmap(ASubBut[i].SubX, ASubBut[i].SubY, ASubBut[i].SubWidth, ASubBut[i].SubHeight,
                           QPixmap(ASubBut[i].SubImgPath));

    painter.setPen(QPen(Qt::yellow, 6, Qt::SolidLine));
    painter.drawRect(QRect(SelBox->GetX() + 95, SelBox->GetY() + 95, 80, 80));
}



void GameWidget::drawDefenseTower(QPainter& painter)
{
    //画出防御塔
    for (auto defei : DefeTowerVec)
    {

        //painter.drawPixmap(defei->GetUpLeftX(), defei->GetUpLeftY(), 80, 80, QPixmap(defei->GetBaseImgPath()));

        //画出所有防御塔的攻击范围
        if(DisplayAllRange)
            painter.drawEllipse(QPoint(defei->GetUpLeftX() + 40, defei->GetUpLeftY() + 40), defei->GetRange(), defei->GetRange());

        //画出所有防御塔子弹
        for (auto bulli : defei->GetBulletVec())
            painter.drawPixmap(bulli->coor.x, bulli->coor.y, defei->GetBulletWidth(), defei->GetBulletHeight(),QPixmap(defei->GetBulletPath()));

        //画出防御塔
        painter.translate(defei->GetUpLeftX() + 40, defei->GetUpLeftY() + 40);          //设置旋转中心
        painter.rotate(defei->GetRotatAngle());             //旋转角度
        painter.translate(-(defei->GetUpLeftX() + 40), -(defei->GetUpLeftY() + 40));    //原点复位
        painter.drawPixmap(defei->GetX(), defei->GetY(), defei->GetWidth(), defei->GetHeight(), QPixmap(defei->GetDefImgPath())/*图片路径*/);

        painter.resetTransform();   //重置调整
    }
}



void GameWidget::drawRangeAndUpgrade(QPainter& painter)//画范围，后来添上了升级按钮
{

    for (auto defei : DefeTowerVec)
        if(defei->GetUpLeftX() == DisplayRangeX && defei->GetUpLeftY() == DisplayRangeY && DisplayRange)
        {
            painter.setPen(QPen(Qt::black));
            painter.drawEllipse(QPoint(DisplayRangeX + 40, DisplayRangeY + 40), defei->GetRange(), defei->GetRange());//范围
            painter.drawPixmap(DisplayRangeX + 10, DisplayRangeY - 80, 60, 60, QPixmap(":/image/up.png"));//升级按钮
            painter.drawPixmap(DisplayRangeX +90,DisplayRangeY-80,60,60,QPixmap(":/image/dismantle.png"));//拆塔按钮


        }
}

void GameWidget::drawExplosion(QPainter& painter)
{

    for (auto expli : ExploEffectCoor)
        painter.drawPixmap(expli->coor.x - (expli->ExplRangeWidth >> 1), expli->coor.y - (expli->ExplRangeHeight >> 1),
                           expli->ExplRangeWidth, expli->ExplRangeHeight, QPixmap(QString(":/image/爆炸效果%1.png").arg(expli->index)));
}

void GameWidget::paintEvent(QPaintEvent *)
{
    QPainter painter(this);

    painter.setRenderHint(QPainter::Antialiasing);
    drawMapArr(painter);
    drawDefenseTower(painter);
    drawMonster(painter);
    drawRangeAndUpgrade(painter);
    drawExplosion(painter);
    drawSelectionBox(painter);
}

void GameWidget::mousePressEvent(QMouseEvent *ev)//！！！！！还存在很大问题！！！！！！//解决了！！！
{
    if (ev->button() != Qt::LeftButton)
        return;


    if (DisplayRange)//显示范围
    {
        if (MouClickRegion(DisplayRangeX + 10, 60 , DisplayRangeY - 80, 60))
        {

            for (auto defei : DefeTowerVec)
                if (defei->GetUpLeftX() == DisplayRangeX && defei->GetUpLeftY() == DisplayRangeY && DisplayRange)
                {
                    if (DeductionMoney(200)) return;//消耗金币
                    defei->SetAttack(defei->GetAttack() + 20);
                    defei->SetWidthHeight(defei->GetWidth() + 12, defei->GetHeight() + 6);//令塔变大相当于升级
                    defei->SetXY(defei->GetX() - 6, defei->GetY() - 3);
                    defei->SetAimsMonster(NULL);
                    defei->SetRange() += 15;//范围变大
                    defei->SetExplRangeWidthHeight(defei->GetExplRangeWidth() + 5, defei->GetExplRangeHeight() + 5);
                    defei->SetBulletWidthHeight(defei->GetBulletWidth() + 5, defei->GetBulletHeight() + 5);
                    break;
                }

            SelBox->SetDisplay(false);
            DisplayRange = false;
            update();
            return;
        }
        if (MouClickRegion(DisplayRangeX + 90, 60 , DisplayRangeY - 80, 60))
        {

                    for (auto & tower : DefeTowerVec)
                    {
                        if (tower->GetUpLeftX() == DisplayRangeX && tower->GetUpLeftY() == DisplayRangeY && DisplayRange)
                        {
                            DefeTowerVec.erase(&tower);
                            money+=RewardMoney;
                            moneylable->setText(QString("money:%1").arg(money));
                        }

                    }
                SelBox->SetDisplay(false);
                DisplayRange = false;
                update();
                return;


          }

//        if (MouClickRegion(DisplayRangeX + 60, 60 , DisplayRangeY - 80, 60))
//        {
//            for(auto defei:DefeTowerVec)
//                if (defei->GetUpLeftX() == DisplayRangeX && defei->GetUpLeftY() == DisplayRangeY && DisplayRange)
//                {

//                    for(auto &it=TowerPitVec.begin();it!=TowerPitVec.end();it++)
//                        delete *it;
//                        TowerPitVec.erase(it);
//                        money+=RewardMoney;
//                        moneylable->setText(QString("money:%1").arg(money));

//                        break;

//                }
//            SelBox->SetDisplay(false);
//            DisplayRange=false;
//            update();
//            return;
//        }
    }

    SubbutObject *ASubBut = SelBox->GetSelSubBut();
    for (int i = 0; i < 4; i++)
        if (MouClickRegion(ASubBut[i].SubX, ASubBut[i].SubWidth, ASubBut[i].SubY, ASubBut[i].SubHeight) && SelBox->GetDisplay())
        {
            SelBox->SetDisplay(false);
            switch (i)
            {
            case 0:
                if (DeductionMoney(100)) return;
                DefeTowerVec.push_back(new HigherAlgebra(SelBox->GetX() + 110, SelBox->GetY() + 112, SelBox->GetX() + 95, SelBox->GetY() + 95, 72, 46));
                break;
            case 1:
                if (DeductionMoney(160)) return;
                DefeTowerVec.push_back(new Programming(SelBox->GetX() + 110, SelBox->GetY() + 112, SelBox->GetX() + 95, SelBox->GetY() + 95, 72, 46));
                break;
            case 2:
                if (DeductionMoney(240)) return;
                DefeTowerVec.push_back(new MathAnalysis(SelBox->GetX() + 110, SelBox->GetY() + 112, SelBox->GetX() + 95, SelBox->GetY() + 95, 76, 50));
                break;
            case 3:
                if (DeductionMoney(400)) return;
                DefeTowerVec.push_back(new CetSix(SelBox->GetX() + 110, SelBox->GetY() + 104, SelBox->GetX() + 95, SelBox->GetY() + 95, 80, 70));
                break;
            default:
                break;
            }

            update();
            return;
        }//子选择框，每个消耗多少钱

    for (auto APit : TowerPitVec)

        if (MouClickRegion(APit->GetX(), APit->GetWidth(), APit->GetY(), APit->GetHeight()))
        {
            DisplayRange = false;
            for (auto defei : DefeTowerVec)
                if(defei->GetUpLeftX() == APit->GetX() && defei->GetUpLeftY() == APit->GetY())
                {
                    DisplayRangeX = defei->GetUpLeftX(), DisplayRangeY = defei->GetUpLeftY();
                    DisplayRange = true;
                    return;
                }

            SelBox->CheckTower(APit->GetX(), APit->GetY());
            update();

            return;
        }

    DisplayRange = false;
    SelBox->SetDisplay(false);

    update();
}

inline bool GameWidget::DeductionMoney(int money)
{
    if(this->money - money < 0) return true;
    this->money -= money;
    moneylable->setText(QString("金币：%1").arg(this->money));
    return false;
}

