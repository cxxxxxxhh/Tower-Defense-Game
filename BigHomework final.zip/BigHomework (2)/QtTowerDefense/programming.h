#ifndef PROGRAMMING_H
#define PROGRAMMING_H

#include "defetowerparent.h"

//火炮塔类，继承防御塔父类//2
class Programming : public DefeTowerParent
{
protected:

public:
    Programming(int x, int y, int FUpLeftX, int FUpLeftY, int Fwidth = 80, int Fheight = 80);
};

#endif // Programming_H
