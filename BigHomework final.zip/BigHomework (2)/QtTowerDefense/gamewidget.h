﻿#ifndef GAMEWIDGET_H////
#define GAMEWIDGET_H

#include <QDialog>
#include <QPainter>
#include <QMouseEvent>
#include <QTimer>
#include "defensetowertype.h"
#include "selectionbox.h"
#include "defetowerparent.h"
#include "enemy.h"
#include <QLabel>
#include <QtMultimedia/qmediaplayer.h>

namespace Ui {
class GameWidget;
}

class GameWidget : public QDialog
{
    Q_OBJECT
public:

    explicit GameWidget(QWidget *parent = 0,int level = 0);
    ~GameWidget();

private:
    QVector<DefenseTowerType*> TowerPitVec;  //防御塔坑数组
    SelectionBox* SelBox = new SelectionBox(":/image/selection.png"); //选择框类

    QVector<DefeTowerParent*> DefeTowerVec; //防御塔父类数组

    QVector<Enemy*> MonsterVec;

    void paintEvent(QPaintEvent *);
    void mousePressEvent(QMouseEvent *);

    void drawMapArr(QPainter&);
    void drawSelectionBox(QPainter&);
    void drawDefenseTower(QPainter&);
    void drawMonster(QPainter&);
    void drawRangeAndUpgrade(QPainter&);
    void drawExplosion(QPainter&);
    //void drawMusic(QPainter&);

    int DisplayRangeX, DisplayRangeY;
    bool DisplayRange = false;

    struct ExploObject
    {
        CoorObject coor;
        int index = 1;

        int ExplRangeWidth;    //爆炸效果宽高
        int ExplRangeHeight;
        //爆炸效果需要初始化坐标、效果宽高
        ExploObject(CoorObject fcoor, int width, int height) : coor(fcoor), ExplRangeWidth(width), ExplRangeHeight(height) {}
    };

    QVector<ExploObject*> ExploEffectCoor;      //爆炸效果坐标数组

    int money = 1000;   //记录金钱
    QLabel *moneylable = new QLabel(this);   //显示金钱标签控件

    inline bool DeductionMoney(int);         //判断金钱是否足够并刷新标签

    int life = 10;  //生命数量

    int wave = 0;

    int counter = 0;

    const int RewardMoney = 28; //每次击败怪物获得的金钱数量

    CoorObject *homecoor = new CoorObject(0, 0);  //记录家的坐标，从地图中自动获取

    void IrodMonsProgDefa(CoorObject**, CoorObject**, CoorObject*, int*, QLabel*); //预设两条路产生怪物方案函数

    const int LevelNumber;      //标识关卡

    bool DisplayAllRange = false;  //标识是否显示所有防御塔的攻击范围


private:
    Ui::GameWidget *ui;
};

#endif // GAMEWIDGET_H
