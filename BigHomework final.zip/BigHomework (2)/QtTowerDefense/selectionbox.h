﻿#ifndef SELECTIONBOX_H
#define SELECTIONBOX_H

#include <QString>
#include "globalstruct.h"   //全局结构

//选择框对象
class SelectionBox
{
private:
    bool display = false;
    int _x = 0, _y = 0;
    const int _width, _height;
    QString SelecBoxImgPath;

    SubbutObject SubBut[4];

public:
    SelectionBox(QString Path, int width = 270, int height = 270);     //构造

    int GetX() const;
    int GetY() const;
    int GetWidth() const;
    int GetHeight() const;
    QString GetImgPath() const; //获取选择框图片路径
    bool GetDisplay() const;
    void SetDisplay(const bool SetPlay); //设置显示状态
    void CheckTower(int x, int y);
    SubbutObject* GetSelSubBut(); //获取子按钮结构数组
};

#endif // SELECTIONBOX_H
