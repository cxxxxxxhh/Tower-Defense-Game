#ifndef MATHANALYSIS_H
#define MATHANALYSIS_H

#include "defetowerparent.h"
//光炮类//4
class MathAnalysis : public DefeTowerParent
{
protected:

public:
    MathAnalysis(int x, int y, int FUpLeftX, int FUpLeftY, int Fwidth = 80, int Fheight = 80);
};

#endif // MATHANALYSIS_H
