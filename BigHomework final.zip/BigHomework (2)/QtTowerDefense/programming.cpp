﻿#pragma execution_character_set("utf-8")
#include "programming.h"

//程设
Programming::Programming(int x, int y, int FUpLeftX, int FUpLeftY, int Fwidth, int Fheight)
{

    _x = x, _y = y;
    DefImgPath = QString(":/image/buyfire.png");
    width = Fwidth, height = Fheight;
    UpLeftX = FUpLeftX, UpLeftY = FUpLeftY;

    Range = 170;

    BullPath = QString(":/image/bullet.png");
    bullwidth = 40, bullheight = 40;

    attack = 65;

    ExplRangeWidth = 70;
    ExplRangeHeight = ExplRangeWidth;
}
