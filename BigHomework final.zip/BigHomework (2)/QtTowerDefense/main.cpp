﻿#pragma execution_character_set("utf-8")////
#include "mainwidget.h"
#include <QApplication>
//#include<QtMultimedia/QMediaPlayer.h>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
//    QMediaPlayer* player=new QMediaPlayer;
//    player->setMedia(QUrl(":/music/easy.m4a"));
//    player->setVolume(100);
//    player->play();
    MainWidget w;
    w.show();
    return a.exec();
}
