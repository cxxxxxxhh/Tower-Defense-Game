﻿#include "mainwidget.h"
#include "ui_mainwidget.h"
#include "gamewidget.h"

MainWidget::MainWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::MainWidget)
{
    ui->setupUi(this);
    setWindowTitle("TowerDefenseGame");

    QPalette pal;
    pal.setBrush(QPalette::Background,QBrush(QPixmap(":/image/bg.jpg")));
    this->setPalette(pal);
}//开始界面

MainWidget::~MainWidget()
{
    delete ui;
}

void MainWidget::on_pushButton_a_clicked()
{
    this->hide();
    GameWidget *m_GameWidget = new GameWidget(NULL,0);
    m_GameWidget->exec();
    this->show();
}

void MainWidget::on_pushButton_b_clicked()
{
    this->hide();
    GameWidget *m_GameWidget = new GameWidget(NULL,2);
    m_GameWidget->exec();
    this->show();
}
