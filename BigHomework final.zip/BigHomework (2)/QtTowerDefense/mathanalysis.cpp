﻿#pragma execution_character_set("utf-8")
#include "mathanalysis.h"

//数分
MathAnalysis::MathAnalysis(int x, int y, int FUpLeftX, int FUpLeftY, int Fwidth, int Fheight)
{

    _x = x, _y = y;
    DefImgPath = QString(":/image/fireonr.png");
    width = Fwidth, height = Fheight;
    UpLeftX = FUpLeftX, UpLeftY = FUpLeftY;

    Range = 260;

    BullPath = QString(":/image/bullet2.png");
    bullwidth = 40, bullheight = 40;

    attack = 94;

    ExplRangeWidth = 75;
    ExplRangeHeight = ExplRangeWidth;
}
