﻿#pragma execution_character_set("utf-8")
#include "cetsix.h"

//六级
CetSix::CetSix(int x, int y, int FUpLeftX, int FUpLeftY, int Fwidth, int Fheight)
{

    _x = x, _y = y;
    DefImgPath = QString(":/image/bigone.png");
    width = Fwidth, height = Fheight;
    UpLeftX = FUpLeftX, UpLeftY = FUpLeftY;

    Range = 230;

    BullPath = QString(":/image/bullet3.png");
    bullwidth = 40, bullheight = 40;

    attack = 118;

    ExplRangeWidth = 85;
    ExplRangeHeight = ExplRangeWidth;
}
