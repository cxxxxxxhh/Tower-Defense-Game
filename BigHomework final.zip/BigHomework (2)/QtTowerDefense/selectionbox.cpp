﻿#pragma execution_character_set("utf-8")
#include "selectionbox.h"


SelectionBox::SelectionBox(QString Path, int width, int height) :
    _width(width), _height(height), SelecBoxImgPath(Path) {}

int SelectionBox::GetX() const
{
    return _x;
}
int SelectionBox::GetY() const
{
    return _y;
}
int SelectionBox::GetWidth() const
{
    return _width;
}
int SelectionBox::GetHeight() const
{
    return _height;
}

QString SelectionBox::GetImgPath() const
{
    return SelecBoxImgPath;
}


bool SelectionBox::GetDisplay() const
{
    return display;
}


void SelectionBox::SetDisplay(const bool SetPlay)
{
    display = SetPlay;
}


void SelectionBox::CheckTower(int x, int y)
{

    _x = x - 95, _y = y - 95;


    SubBut[0].SubX = _x + 106, SubBut[0].SubY = _y + 14;
    SubBut[0].SubImgPath = QString(":/image/buygreen.png");

    SubBut[1].SubX = _x + 14, SubBut[1].SubY = _y + 106;
    SubBut[1].SubImgPath = QString(":/image/buyfire.png");

    SubBut[2].SubX = _x + 202, SubBut[2].SubY = _y + 106;
    SubBut[2].SubImgPath = QString(":/image/fireonr.png");

    SubBut[3].SubX = _x + 106, SubBut[3].SubY = _y + 190;
    SubBut[3].SubImgPath = QString(":/image/bigone.png");

    display = true;
}


SubbutObject* SelectionBox::GetSelSubBut()
{
    return SubBut;
}
