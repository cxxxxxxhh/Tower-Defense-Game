#ifndef HIGHERALGEBRA_H
#define HIGHERALGEBRA_H

#include "defetowerparent.h"

//绿色炮塔类，继承防御塔父类//3
class HigherAlgebra : public DefeTowerParent
{
protected:

public:
    HigherAlgebra(int x, int y, int FUpLeftX, int FUpLeftY, int Fwidth = 80, int Fheight = 80);
};

#endif // HIGHERALGEBRA_H
