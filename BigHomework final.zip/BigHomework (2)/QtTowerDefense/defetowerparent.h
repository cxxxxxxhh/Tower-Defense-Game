﻿#ifndef DEFETOWERPARENT_H
#define DEFETOWERPARENT_H

#include <QString>
#include "enemy.h"    //怪物类头文件

//防御塔父类
class DefeTowerParent
{
protected:
    int _x, _y;
    int width, height;
    QString DefImgPath;
    int RotatAngle = 0;
    int UpLeftX, UpLeftY;
    int Range;

    Enemy* aimsmon = NULL;//记录防御塔的目标怪物

    QString BullPath;       //子弹图片路径
    int power;              //子弹威力
    int bullwidth, bullheight;      //子弹宽高
    QVector<BulletObject*> BulletVec;  //子弹结构数组
    int counter = 0;
    int attack;

    int ExplRangeWidth;
    int ExplRangeHeight;

public:
    int GetX() const;
    int GetY() const;
    int GetWidth() const;
    int GetHeight() const;
    int GetRotatAngle() const;
    QString GetBaseImgPath() const;
    QString GetDefImgPath() const;
    int GetUpLeftX() const;
    int GetUpLeftY() const;
    void SetRotatAngle(int rot);   //设置旋转角度
    int GetRange() const;   //设置防御塔的射程

    Enemy* GetAimsMonster() const;
    void SetAimsMonster(Enemy*);


    QString GetBulletPath() const;  //返回防御塔子弹图片路径
    QVector<BulletObject*>& GetBulletVec();//返回子弹数组
    void InterBullet();
    void BulletMove();
    int GetBulletWidth() const;
    int GetBulletHeight() const;
    int GetAttack() const;
    //升级
    void SetAttack(int);
    void SetWidthHeight(int, int);
    void SetXY(int, int);
    int& SetRange();

    int GetExplRangeWidth() const;
    int GetExplRangeHeight() const;
    void SetExplRangeWidthHeight(int, int); //设置防御塔对应的爆炸效果的宽高

    void SetBulletWidthHeight(int, int);    //设置子弹宽高
};

#endif // DEFETOWERPARENT_H
